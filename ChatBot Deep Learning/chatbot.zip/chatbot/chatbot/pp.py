# from flask import Flask, request, render_template

# app = Flask(__name__)#,template_folder="template")

# @app.route('/')
# def my_form():
#     return render_template('index.html')

# @app.route('/reply', methods=['POST'])
# def my_form_post():

#     text = request.form['msg']
#     return  text.upper()
# if __name__ == "__main__":
#     app.run(debug=True)
import urllib, json
import urllib.request
url =  'https://raw.githubusercontent.com/taruntiwarihp/dataSets/master/CakeGift/intents.json'

data = urllib.request.urlopen(url).read().decode()
# parse json object
intents = json.loads(data)
tag = "greeting"
# for obj in intents:
#     if tag == obj['tag']:
#         print(True)

for dict in intents:
    if dict['tag'] == tag:
        print("TY")
        # return dict['price']
# print([obj for obj in intents if obj['tag']==tag][0]['responses'])
