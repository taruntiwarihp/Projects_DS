
function openform() {
    document.getElementById("myform").style.display="block";
}
function closeform() {
    document.getElementById("myform").style.display="none";
}
